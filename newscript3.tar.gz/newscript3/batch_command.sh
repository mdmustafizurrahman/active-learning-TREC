#!/bin/sh

sbatch activeJobTREC820
sbatch activeJobTREC840
sbatch activeJobTREC860
sbatch activeJobTREC880
sbatch activeJobTREC891
