#!/bin/sh

sbatch activeJobTREC25
sbatch activeJobTREC30