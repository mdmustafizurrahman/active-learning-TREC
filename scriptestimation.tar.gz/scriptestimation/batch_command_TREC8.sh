#!/bin/sh

sbatch activeJobTREC5
sbatch activeJobTREC10
sbatch activeJobTREC15
sbatch activeJobTREC20