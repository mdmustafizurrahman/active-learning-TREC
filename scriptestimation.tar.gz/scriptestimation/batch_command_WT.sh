#!/bin/sh

sbatch activeJobTREC50
sbatch activeJobTREC60
sbatch activeJobTREC70
sbatch activeJobTREC80