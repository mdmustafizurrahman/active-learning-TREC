#!/bin/sh

sbatch activeJobTREC5
sbatch activeJobTREC10