#!/bin/sh

sbatch activeJobTREC30
sbatch activeJobTREC40