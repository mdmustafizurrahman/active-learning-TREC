#!/bin/sh

sbatch activeJobTREC20