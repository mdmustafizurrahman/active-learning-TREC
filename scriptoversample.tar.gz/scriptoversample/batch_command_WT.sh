#!/bin/sh

sbatch activeJobTREC70
sbatch activeJobTREC80
sbatch activeJobTREC90
sbatch activeJobTREC100
sbatch activeJobTREC110
sbatch activeJobTREC120