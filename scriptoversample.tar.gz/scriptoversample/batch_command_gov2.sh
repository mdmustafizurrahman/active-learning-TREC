#!/bin/sh

sbatch activeJobTREC40
sbatch activeJobTREC50
sbatch activeJobTREC60